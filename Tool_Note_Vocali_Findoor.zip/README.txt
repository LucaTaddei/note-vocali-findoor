ISTRUZIONI PER USO - TOOL NOTE VOCALI FINDOOR

1. Apri il file 'index.html' con un browser (Chrome consigliato).
2. Premi su "Inizia Dettatura" per registrare la tua nota vocale.
3. Modifica il testo se necessario nella casella.
4. Premi su "Crea Email" per aprire direttamente la tua app mail con il testo già pronto.

📱 Per smartphone:
- Apri il file dal browser e salva come 'Aggiungi a schermata Home'.

💻 Per PC:
- Clic destro su 'index.html' → Crea collegamento → Trascina sul desktop.
